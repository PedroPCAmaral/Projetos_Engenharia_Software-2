#include <stdio.h>
int main() { int a = 5; int b = 11; float c;
scanf("%d %d", &a, &b);
1
2
3
4
5
6
7
8
	if(a > b || !(a > c = (float)(b	0)) {
/ a);
	} else { c = (float)(a	/ b);
	}
printf("%.2f\n",	c);
}	return 0;
