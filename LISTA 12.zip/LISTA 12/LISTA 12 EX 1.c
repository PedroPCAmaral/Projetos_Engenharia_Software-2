#include <stdio.h>
#include <stdlib.h>

typedef struct Aluno {
    char nome[100];
    int faltas;
    float nota;
} aluno_t;

int main() {
    aluno_t *aluno;

    
    aluno = (aluno_t*) malloc(sizeof(aluno_t));

    
    if (aluno == NULL) {
        printf("Erro na alocação de memória.\n");
        return 1;
    }

    
    printf("Digite o nome do aluno: ");
    fgets(aluno->nome, sizeof(aluno->nome), stdin);
    printf("Digite o numero de faltas: ");
    scanf("%d", &aluno->faltas);
    printf("Digite a nota do aluno: ");
    scanf("%f", &aluno->nota);

    
    printf("\nNome: %s", aluno->nome);
    printf("Faltas: %d\n", aluno->faltas);
    printf("Nota: %.2f\n", aluno->nota);

    
    if (aluno->nota >= 7.0 && aluno->faltas <= 25) {
        printf("Aprovado!\n");
    } else {
        printf("Reprovado!\n");
    }

    
    free(aluno);
    return 0;
}
