#include <stdio.h>

typedef struct Aluno {
    char nome[100];
    float nota;
    int faltas;
} aluno_t;

int main() {
    aluno_t aluno;

    printf("Digite o nome do aluno: ");
    fgets(aluno.nome, sizeof(aluno.nome), stdin);
    printf("Digite a nota do aluno: ");
    scanf("%f", &aluno.nota);
    printf("Digite o numero de faltas: ");
    scanf("%d", &aluno.faltas);

    if (aluno.nota >= 7.0 && aluno.faltas <= 25) {
        printf("Aprovado!\n");
    } else {
        printf("Reprovado!\n");
    }

    return 0;
}
